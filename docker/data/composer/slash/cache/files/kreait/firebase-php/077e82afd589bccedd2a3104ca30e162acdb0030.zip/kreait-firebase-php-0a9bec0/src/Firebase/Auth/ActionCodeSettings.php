<?php

declare(strict_types=1);

namespace Kreait\Firebase\Auth;

interface ActionCodeSettings
{
    public function toArray(): array;
}
