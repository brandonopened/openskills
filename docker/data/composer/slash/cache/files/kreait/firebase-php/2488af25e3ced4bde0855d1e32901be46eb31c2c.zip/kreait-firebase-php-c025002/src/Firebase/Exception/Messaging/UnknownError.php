<?php

declare(strict_types=1);

namespace Kreait\Firebase\Exception\Messaging;

/**
 * @deprecated 4.28.0 catch specific exceptions or \Kreait\Firebase\Exception\MessagingException instead
 */
interface UnknownError
{
}
