<?php

declare(strict_types=1);

namespace Kreait\Firebase\Exception;

/**
 * @deprecated 4.28.0 Catch \Kreait\Firebase\Exception\Database\UnsupportedQuery instead
 */
interface IndexNotDefined extends QueryException
{
}
