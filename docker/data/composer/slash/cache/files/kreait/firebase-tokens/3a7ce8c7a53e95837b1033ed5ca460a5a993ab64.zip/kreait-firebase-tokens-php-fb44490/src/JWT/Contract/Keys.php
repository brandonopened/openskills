<?php

declare(strict_types=1);

namespace Kreait\Firebase\JWT\Contract;

interface Keys
{
    public function all(): array;
}
