<?php

namespace Doctrine\DBAL\Driver\IBMDB2;

use Exception;

/**
 * @psalm-immutable
 */
class DB2Exception extends Exception
{
}
