## This bundle became deprecated

Please be aware that this bundle became deprecated and won't be compatible with Symfony 5 and upwards.
Read more about the deprecation and the alternatives for this bundle in the issue 
[#156](https://github.com/doctrine/DoctrineCacheBundle/issues/156).
