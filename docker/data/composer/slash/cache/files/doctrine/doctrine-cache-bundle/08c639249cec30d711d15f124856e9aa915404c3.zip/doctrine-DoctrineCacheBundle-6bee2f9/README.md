DoctrineCacheBundle
===================

Symfony Bundle for Doctrine Cache.

Master: [![Build Status](https://secure.travis-ci.org/doctrine/DoctrineCacheBundle.svg?branch=master)](https://travis-ci.org/doctrine/DoctrineCacheBundle)

Master: [![Coverage Status](https://coveralls.io/repos/doctrine/DoctrineCacheBundle/badge.png?branch=master)](https://coveralls.io/r/doctrine/DoctrineCacheBundle?branch=master)

## Deprecation warning

This bundle is deprecated; it will not be updated for Symfony 5. If you want to
use doctrine/cache in Symfony, please configure the services manually. When
using Symfony, we no longer recommend configuring doctrine/cache through this
bundle. Instead, you should use symfony/cache for your cache needs. However, the
deprecation does not extend to doctrine/cache, you'll be able to use those
classes as you did so far.
