<?php
namespace Psalm\Issue;

class MixedReturnTypeCoercion extends CodeIssue
{
}
