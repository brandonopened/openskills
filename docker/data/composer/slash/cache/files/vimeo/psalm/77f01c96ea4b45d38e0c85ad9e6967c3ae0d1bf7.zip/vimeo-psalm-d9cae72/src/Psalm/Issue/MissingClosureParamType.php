<?php
namespace Psalm\Issue;

class MissingClosureParamType extends CodeIssue
{
}
