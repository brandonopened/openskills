<?php
namespace Psalm\Issue;

class ImpureMethodCall extends CodeIssue
{
}
