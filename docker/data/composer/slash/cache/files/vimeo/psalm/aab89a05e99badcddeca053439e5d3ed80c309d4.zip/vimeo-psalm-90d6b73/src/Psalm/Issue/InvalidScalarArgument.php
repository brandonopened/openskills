<?php
namespace Psalm\Issue;

class InvalidScalarArgument extends ArgumentIssue
{
}
