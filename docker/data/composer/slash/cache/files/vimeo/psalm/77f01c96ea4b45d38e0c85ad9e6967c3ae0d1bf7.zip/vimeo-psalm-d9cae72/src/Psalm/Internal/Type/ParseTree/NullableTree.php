<?php
namespace Psalm\Internal\Type\ParseTree;

/**
 * @internal
 */
class NullableTree extends \Psalm\Internal\Type\ParseTree
{
}
