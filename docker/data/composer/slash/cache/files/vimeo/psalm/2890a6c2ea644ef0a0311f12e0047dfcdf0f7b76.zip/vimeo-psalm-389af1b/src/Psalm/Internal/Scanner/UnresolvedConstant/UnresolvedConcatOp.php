<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

class UnresolvedConcatOp extends UnresolvedBinaryOp
{
}
