<?php
namespace Psalm\Internal\Type\ParseTree;

/**
 * @internal
 */
class Root extends \Psalm\Internal\Type\ParseTree
{
}
