<?php
namespace Psalm\Issue;

class InaccessibleClassConstant extends CodeIssue
{
}
