# MissingClosureReturnType

Emitted when a closure lacks a return type

```php
<?php

$a = function() {
    return "foo";
};
```
