<?php
namespace Psalm\Issue;

class PossiblyInvalidPropertyAssignmentValue extends PropertyIssue
{
}
