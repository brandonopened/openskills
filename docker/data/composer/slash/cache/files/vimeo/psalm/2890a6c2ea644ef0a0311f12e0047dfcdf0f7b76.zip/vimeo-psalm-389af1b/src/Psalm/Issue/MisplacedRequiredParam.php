<?php
namespace Psalm\Issue;

/**
 * @psalm-suppress UnusedClass because it's deprecated
 */
class MisplacedRequiredParam extends CodeIssue
{
}
