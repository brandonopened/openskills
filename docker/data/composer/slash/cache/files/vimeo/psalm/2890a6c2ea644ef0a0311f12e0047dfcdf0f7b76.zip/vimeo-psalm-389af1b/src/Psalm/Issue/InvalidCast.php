<?php
namespace Psalm\Issue;

class InvalidCast extends CodeIssue
{
}
