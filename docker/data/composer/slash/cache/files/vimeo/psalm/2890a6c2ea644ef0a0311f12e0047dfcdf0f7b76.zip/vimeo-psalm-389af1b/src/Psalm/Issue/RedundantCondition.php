<?php
namespace Psalm\Issue;

class RedundantCondition extends CodeIssue
{
}
