<?php
namespace Psalm\Issue;

class InvalidMethodCall extends CodeIssue
{
}
