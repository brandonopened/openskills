<?php
namespace Psalm\Issue;

class PossibleRawObjectIteration extends CodeIssue
{
}
