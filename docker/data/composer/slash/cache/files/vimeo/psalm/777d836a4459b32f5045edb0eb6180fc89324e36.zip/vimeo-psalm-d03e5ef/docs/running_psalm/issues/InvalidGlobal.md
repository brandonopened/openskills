# InvalidGlobal

Emitted when there's a reference to the global keyword where it's not expected

```php
<?php

global $e;
```
