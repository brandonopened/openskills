<?php
namespace Psalm\Issue;

class MethodSignatureMustOmitReturnType extends CodeIssue
{
}
