<?php
namespace Psalm\Issue;

class PossiblyUndefinedStringArrayOffset extends CodeIssue
{
}
