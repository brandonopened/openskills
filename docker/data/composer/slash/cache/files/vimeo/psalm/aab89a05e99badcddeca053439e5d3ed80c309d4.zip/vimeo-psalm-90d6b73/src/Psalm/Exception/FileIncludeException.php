<?php
namespace Psalm\Exception;

class FileIncludeException extends \Exception
{
}
