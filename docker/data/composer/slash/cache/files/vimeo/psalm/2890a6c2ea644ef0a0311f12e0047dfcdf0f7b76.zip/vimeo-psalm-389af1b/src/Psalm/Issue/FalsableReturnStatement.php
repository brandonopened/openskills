<?php
namespace Psalm\Issue;

class FalsableReturnStatement extends CodeIssue
{
}
