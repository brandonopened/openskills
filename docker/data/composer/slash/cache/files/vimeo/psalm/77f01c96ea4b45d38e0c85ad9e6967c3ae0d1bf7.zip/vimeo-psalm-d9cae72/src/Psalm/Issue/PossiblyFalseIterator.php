<?php
namespace Psalm\Issue;

class PossiblyFalseIterator extends CodeIssue
{
}
