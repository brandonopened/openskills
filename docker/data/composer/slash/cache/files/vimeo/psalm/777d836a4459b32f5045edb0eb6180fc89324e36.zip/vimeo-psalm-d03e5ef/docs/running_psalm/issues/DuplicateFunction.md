# DuplicateFunction

Emitted when a function is defined twice

```php
<?php

function foo() : void {}
function bar() : void {}
function foo() : void {}
```
