# InvalidIterator

Emitted when trying to iterate over a value that's not iterable

```php
<?php

$a = 5;
foreach ($a as $b) {}
```
