<?php
namespace Psalm\Issue;

class DeprecatedMethod extends MethodIssue
{
}
