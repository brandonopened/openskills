<?php
namespace Psalm\Issue;

class MissingDocblockType extends CodeIssue
{
}
