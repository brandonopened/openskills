<?php
namespace Psalm\Issue;

class PossiblyNullPropertyAssignmentValue extends PropertyIssue
{
}
