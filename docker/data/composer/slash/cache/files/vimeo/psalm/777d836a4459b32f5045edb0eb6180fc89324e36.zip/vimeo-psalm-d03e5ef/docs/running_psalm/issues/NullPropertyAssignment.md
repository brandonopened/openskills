# NullPropertyAssignment

Emitted when trying to set a property on `null`

```php
<?php

$a = null;
$a->foo = "bar";
```
