# MissingParamType

Emitted when a function parameter has no type information associated with it

```php
<?php

function foo($a) : void {}
```
