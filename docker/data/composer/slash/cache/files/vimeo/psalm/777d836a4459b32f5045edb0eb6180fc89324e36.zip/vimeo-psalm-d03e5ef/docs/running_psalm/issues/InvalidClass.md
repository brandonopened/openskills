# InvalidClass

Emitted when referencing a class with the wrong casing

```php
<?php

class Foo {}
(new foo());
```
