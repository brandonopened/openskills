<?php
namespace Psalm\Exception;

class RefactorException extends \Exception
{
}
