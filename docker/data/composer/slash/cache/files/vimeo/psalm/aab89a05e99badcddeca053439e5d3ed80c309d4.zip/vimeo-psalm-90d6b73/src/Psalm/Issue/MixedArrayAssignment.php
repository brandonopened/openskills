<?php
namespace Psalm\Issue;

class MixedArrayAssignment extends CodeIssue
{
}
