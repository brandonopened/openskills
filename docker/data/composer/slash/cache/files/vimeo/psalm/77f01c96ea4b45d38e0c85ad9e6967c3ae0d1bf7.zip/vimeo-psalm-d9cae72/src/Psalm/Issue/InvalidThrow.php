<?php
namespace Psalm\Issue;

class InvalidThrow extends ClassIssue
{
}
