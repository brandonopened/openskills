<?php
namespace Psalm\Issue;

class MissingPropertyType extends CodeIssue
{
}
