<?php
namespace Psalm\Internal\Type\ParseTree;

/**
 * @internal
 */
class UnionTree extends \Psalm\Internal\Type\ParseTree
{
}
