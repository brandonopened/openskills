<?php
namespace Psalm\Issue;

class InvalidReturnStatement extends CodeIssue
{
}
