<?php
namespace Psalm\Issue;

class MixedPropertyTypeCoercion extends PropertyIssue
{
}
