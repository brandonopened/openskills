<?php
namespace Psalm\Issue;

class NullOperand extends CodeIssue
{
}
