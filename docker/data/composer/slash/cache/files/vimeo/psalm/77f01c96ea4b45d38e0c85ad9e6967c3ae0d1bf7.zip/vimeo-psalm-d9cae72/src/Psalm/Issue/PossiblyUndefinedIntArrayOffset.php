<?php
namespace Psalm\Issue;

class PossiblyUndefinedIntArrayOffset extends CodeIssue
{
}
