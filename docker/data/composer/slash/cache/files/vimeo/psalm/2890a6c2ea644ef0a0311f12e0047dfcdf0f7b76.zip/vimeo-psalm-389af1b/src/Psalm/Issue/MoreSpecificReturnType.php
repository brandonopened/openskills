<?php
namespace Psalm\Issue;

class MoreSpecificReturnType extends CodeIssue
{
}
