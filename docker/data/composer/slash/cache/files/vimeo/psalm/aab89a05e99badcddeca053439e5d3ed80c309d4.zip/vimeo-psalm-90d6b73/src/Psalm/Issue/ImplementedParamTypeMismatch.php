<?php
namespace Psalm\Issue;

class ImplementedParamTypeMismatch extends CodeIssue
{
}
