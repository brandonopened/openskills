<?php
namespace Psalm\Issue;

class MixedArrayTypeCoercion extends CodeIssue
{
}
