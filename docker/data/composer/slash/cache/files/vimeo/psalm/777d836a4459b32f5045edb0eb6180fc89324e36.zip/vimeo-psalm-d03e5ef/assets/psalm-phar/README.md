This allows you to install [Psalm](https://github.com/vimeo/psalm) without worrying about composer conflicts.
