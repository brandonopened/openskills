<?php
namespace Psalm\Issue;

class MixedReturnStatement extends CodeIssue
{
}
