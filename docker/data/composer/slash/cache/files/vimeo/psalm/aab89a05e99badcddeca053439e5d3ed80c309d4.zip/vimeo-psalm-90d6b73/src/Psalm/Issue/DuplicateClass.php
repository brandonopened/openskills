<?php
namespace Psalm\Issue;

class DuplicateClass extends CodeIssue
{
}
