<?php
namespace Psalm\Issue;

class PossiblyInvalidOperand extends CodeIssue
{
}
