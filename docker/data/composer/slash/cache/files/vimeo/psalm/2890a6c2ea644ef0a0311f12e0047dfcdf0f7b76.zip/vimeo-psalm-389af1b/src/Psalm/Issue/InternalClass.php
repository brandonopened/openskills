<?php
namespace Psalm\Issue;

class InternalClass extends ClassIssue
{
}
