<?php
namespace Psalm\Issue;

class InvalidArrayAssignment extends CodeIssue
{
}
