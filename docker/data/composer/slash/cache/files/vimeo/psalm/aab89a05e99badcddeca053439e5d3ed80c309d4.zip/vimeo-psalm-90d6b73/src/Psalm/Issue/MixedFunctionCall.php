<?php

namespace Psalm\Issue;

class MixedFunctionCall extends CodeIssue
{
}
