<?php
namespace Psalm\Issue;

class OverriddenMethodAccess extends CodeIssue
{
}
