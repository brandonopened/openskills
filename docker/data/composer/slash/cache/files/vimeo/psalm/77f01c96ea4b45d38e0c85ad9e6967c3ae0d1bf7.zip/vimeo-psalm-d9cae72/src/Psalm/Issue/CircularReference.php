<?php
namespace Psalm\Issue;

class CircularReference extends CodeIssue
{
}
