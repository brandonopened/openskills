<?php
namespace Psalm\Issue;

class LoopInvalidation extends CodeIssue
{
}
