<?php
namespace Psalm\Issue;

class MoreSpecificImplementedParamType extends CodeIssue
{
}
