<?php
namespace Psalm\Issue;

class InvalidGlobal extends CodeIssue
{
}
