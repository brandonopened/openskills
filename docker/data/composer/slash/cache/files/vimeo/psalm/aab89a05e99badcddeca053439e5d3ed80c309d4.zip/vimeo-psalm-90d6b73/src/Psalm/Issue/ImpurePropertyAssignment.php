<?php
namespace Psalm\Issue;

class ImpurePropertyAssignment extends CodeIssue
{
}
