<?php
namespace Psalm\Issue;

class ParentNotFound extends CodeIssue
{
}
