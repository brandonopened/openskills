<?php
namespace Psalm\Issue;

class ImpureStaticVariable extends CodeIssue
{
}
