<?php
namespace Psalm\Exception;

class DocblockParseException extends \Exception
{
}
