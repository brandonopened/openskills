<?php
namespace Psalm\Issue;

class PossiblyUnusedMethod extends MethodIssue
{
}
