<?php
namespace Psalm\Issue;

class MissingConstructor extends CodeIssue
{
}
