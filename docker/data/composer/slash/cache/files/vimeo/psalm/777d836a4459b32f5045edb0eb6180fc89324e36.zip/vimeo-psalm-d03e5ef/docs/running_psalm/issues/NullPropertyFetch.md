# NullPropertyFetch

Emitted when trying to fetch a property on a `null` value

```php
<?php

$a = null;
echo $a->foo;
```
