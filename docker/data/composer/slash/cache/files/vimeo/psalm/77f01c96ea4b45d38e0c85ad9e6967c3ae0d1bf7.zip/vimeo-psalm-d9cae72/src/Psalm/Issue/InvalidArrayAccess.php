<?php
namespace Psalm\Issue;

class InvalidArrayAccess extends CodeIssue
{
}
