<?php
namespace Psalm\Issue;

class InvalidPropertyFetch extends CodeIssue
{
}
