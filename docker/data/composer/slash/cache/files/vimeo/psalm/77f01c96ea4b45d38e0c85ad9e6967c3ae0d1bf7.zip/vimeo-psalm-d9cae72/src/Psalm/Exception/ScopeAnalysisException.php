<?php
namespace Psalm\Exception;

class ScopeAnalysisException extends \Exception
{
}
