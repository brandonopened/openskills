<?php
namespace Psalm\Issue;

class InvalidOperand extends CodeIssue
{
}
