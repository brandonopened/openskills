<?php
namespace Psalm\Issue;

class MixedPropertyAssignment extends CodeIssue
{
}
