<?php
namespace Psalm\Issue;

class InvalidDocblock extends CodeIssue
{
}
