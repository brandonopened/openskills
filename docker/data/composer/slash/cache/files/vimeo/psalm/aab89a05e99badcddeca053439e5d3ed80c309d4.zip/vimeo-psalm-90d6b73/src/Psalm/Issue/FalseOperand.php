<?php
namespace Psalm\Issue;

class FalseOperand extends CodeIssue
{
}
