<?php
namespace Psalm\Issue;

/**
 * @deprecated use more specific classes
 * @psalm-suppress UnusedClass
 */
class MixedTypeCoercion extends ArgumentIssue
{
}
