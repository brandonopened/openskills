<?php
namespace Psalm\Issue;

class TaintedInput extends CodeIssue
{
}
