<?php
namespace Psalm\Issue;

class NonStaticSelfCall extends CodeIssue
{
}
