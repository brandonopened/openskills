<?php
namespace Psalm\Issue;

class MixedArrayAccess extends CodeIssue
{
}
