# NullOperand

Emitted when using `null` as part of an operation (e.g. `+`, `.`, `^` etc.)

```php
<?php

echo null . 'hello';
```
