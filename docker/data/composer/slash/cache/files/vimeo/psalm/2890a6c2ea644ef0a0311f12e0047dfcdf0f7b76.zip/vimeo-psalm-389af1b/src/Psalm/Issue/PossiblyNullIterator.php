<?php
namespace Psalm\Issue;

class PossiblyNullIterator extends CodeIssue
{
}
