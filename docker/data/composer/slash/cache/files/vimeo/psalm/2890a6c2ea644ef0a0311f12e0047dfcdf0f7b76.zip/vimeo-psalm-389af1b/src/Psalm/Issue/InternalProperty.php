<?php
namespace Psalm\Issue;

class InternalProperty extends PropertyIssue
{
}
