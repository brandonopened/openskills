# InvalidReturnStatement

Emitted when a function return statement is incorrect

```php
<?php

function foo() : string {
    return 5; // emitted here
}
```
