<?php
namespace Psalm\Issue;

class MissingDependency extends ClassIssue
{
}
