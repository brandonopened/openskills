# ForbiddenEcho

Emitted when Psalm encounters an echo statement and the `forbidEcho` flag in your config is set to `true`

```php
<?php

echo("bah");
```
