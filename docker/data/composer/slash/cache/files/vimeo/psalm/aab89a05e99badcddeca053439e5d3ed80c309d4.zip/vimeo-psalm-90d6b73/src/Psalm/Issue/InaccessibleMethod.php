<?php
namespace Psalm\Issue;

class InaccessibleMethod extends CodeIssue
{
}
