# UndefinedFunction

Emitted when referencing a function that doesn't exist

```php
<?php

foo();
```
