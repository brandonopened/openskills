<?php
namespace Psalm\Issue;

class PossiblyNullOperand extends CodeIssue
{
}
