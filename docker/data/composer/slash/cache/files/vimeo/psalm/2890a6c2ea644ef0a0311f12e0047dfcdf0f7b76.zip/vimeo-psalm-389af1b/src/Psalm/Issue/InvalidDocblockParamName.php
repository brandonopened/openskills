<?php
namespace Psalm\Issue;

class InvalidDocblockParamName extends CodeIssue
{
}
