<?php
namespace Psalm\Issue;

class InterfaceInstantiation extends CodeIssue
{
}
