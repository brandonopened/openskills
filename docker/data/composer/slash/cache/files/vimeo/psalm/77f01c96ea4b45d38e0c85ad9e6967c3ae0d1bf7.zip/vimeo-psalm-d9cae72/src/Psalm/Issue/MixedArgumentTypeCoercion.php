<?php
namespace Psalm\Issue;

class MixedArgumentTypeCoercion extends ArgumentIssue
{
}
