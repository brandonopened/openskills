<?php
namespace Psalm\Issue;

class NullReference extends CodeIssue
{
}
