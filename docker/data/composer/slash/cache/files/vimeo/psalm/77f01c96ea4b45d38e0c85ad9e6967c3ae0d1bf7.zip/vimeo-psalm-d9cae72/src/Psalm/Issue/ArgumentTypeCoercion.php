<?php
namespace Psalm\Issue;

class ArgumentTypeCoercion extends ArgumentIssue
{
}
