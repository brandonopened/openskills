<?php
namespace Psalm\Issue;

class PossiblyUndefinedGlobalVariable extends CodeIssue
{
}
