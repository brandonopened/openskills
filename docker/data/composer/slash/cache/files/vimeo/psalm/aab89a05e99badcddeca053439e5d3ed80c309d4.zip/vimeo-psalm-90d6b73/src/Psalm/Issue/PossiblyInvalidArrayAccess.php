<?php
namespace Psalm\Issue;

class PossiblyInvalidArrayAccess extends CodeIssue
{
}
