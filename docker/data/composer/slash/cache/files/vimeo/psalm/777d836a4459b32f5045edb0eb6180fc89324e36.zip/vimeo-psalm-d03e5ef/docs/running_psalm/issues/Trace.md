# Trace

Not really an issue. Just reports type of the variable.

```php
<?php

/** @psalm-trace $x */
$x = getmypid();
```

## How to fix

Use it for debugging purposes, not for production
