<?php
namespace Psalm\Issue;

class DeprecatedInterface extends ClassIssue
{
}
