<?php

namespace Psalm\Exception;

class InvalidClasslikeOverrideException extends \Exception
{
}
