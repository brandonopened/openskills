<?php
namespace Psalm\Issue;

class InvalidTemplateParam extends CodeIssue
{
}
