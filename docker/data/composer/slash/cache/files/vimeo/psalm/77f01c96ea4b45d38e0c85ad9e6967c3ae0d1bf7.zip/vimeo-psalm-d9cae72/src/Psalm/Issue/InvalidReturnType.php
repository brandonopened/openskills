<?php
namespace Psalm\Issue;

class InvalidReturnType extends CodeIssue
{
}
