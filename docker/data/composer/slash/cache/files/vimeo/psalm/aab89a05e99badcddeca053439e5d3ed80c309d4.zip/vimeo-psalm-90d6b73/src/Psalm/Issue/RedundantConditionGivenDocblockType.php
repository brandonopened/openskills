<?php
namespace Psalm\Issue;

class RedundantConditionGivenDocblockType extends CodeIssue
{
}
