<?php
namespace Psalm\Issue;

class InvalidScope extends CodeIssue
{
}
