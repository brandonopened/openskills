<?php
namespace Psalm\Issue;

class StringIncrement extends CodeIssue
{
}
