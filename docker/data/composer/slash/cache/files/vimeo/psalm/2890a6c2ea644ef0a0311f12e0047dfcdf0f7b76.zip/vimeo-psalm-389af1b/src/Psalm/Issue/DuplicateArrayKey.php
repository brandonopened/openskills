<?php
namespace Psalm\Issue;

class DuplicateArrayKey extends CodeIssue
{
}
