<?php
namespace Psalm\Issue;

class DuplicateFunction extends CodeIssue
{
}
