<?php
namespace Psalm\Issue;

class MissingFile extends CodeIssue
{
}
