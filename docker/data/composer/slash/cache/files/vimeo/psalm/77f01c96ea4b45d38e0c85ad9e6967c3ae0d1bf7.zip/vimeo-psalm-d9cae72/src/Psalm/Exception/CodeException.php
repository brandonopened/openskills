<?php
namespace Psalm\Exception;

class CodeException extends \Exception
{
}
