<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

class UnresolvedMultiplicationOp extends UnresolvedBinaryOp
{
}
