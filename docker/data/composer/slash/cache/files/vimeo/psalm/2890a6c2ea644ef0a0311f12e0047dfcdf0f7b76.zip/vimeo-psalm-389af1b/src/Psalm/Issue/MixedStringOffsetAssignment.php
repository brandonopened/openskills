<?php
namespace Psalm\Issue;

class MixedStringOffsetAssignment extends CodeIssue
{
}
