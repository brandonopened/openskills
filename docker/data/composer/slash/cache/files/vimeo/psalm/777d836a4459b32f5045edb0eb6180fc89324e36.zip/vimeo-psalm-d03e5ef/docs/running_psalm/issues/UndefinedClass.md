# UndefinedClass

Emitted when referencing a class that does not exist

```php
<?php

$a = new A();
```
