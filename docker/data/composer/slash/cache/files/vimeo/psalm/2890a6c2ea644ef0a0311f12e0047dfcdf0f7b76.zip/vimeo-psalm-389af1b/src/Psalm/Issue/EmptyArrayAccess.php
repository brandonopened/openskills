<?php
namespace Psalm\Issue;

class EmptyArrayAccess extends CodeIssue
{
}
