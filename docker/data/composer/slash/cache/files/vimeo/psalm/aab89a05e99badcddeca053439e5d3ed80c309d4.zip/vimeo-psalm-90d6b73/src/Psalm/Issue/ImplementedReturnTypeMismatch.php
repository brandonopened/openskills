<?php
namespace Psalm\Issue;

class ImplementedReturnTypeMismatch extends CodeIssue
{
}
