<?php
namespace Psalm\Issue;

class ForbiddenEcho extends CodeIssue
{
}
