<?php
namespace Psalm\Internal\Type\ParseTree;

/**
 * @internal
 */
class MethodWithReturnTypeTree extends \Psalm\Internal\Type\ParseTree
{
}
