# TypeDoesNotContainType

Emitted checking whether one value has a type or value that is impossible given its currently-known type

```php
<?php

$a = "hello";
if ($a === 5) {}
```
