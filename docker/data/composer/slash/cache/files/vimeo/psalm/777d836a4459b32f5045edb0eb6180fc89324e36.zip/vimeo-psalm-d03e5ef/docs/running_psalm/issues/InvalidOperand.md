# InvalidOperand

Emitted when using something as an operand that is unexpected

```php
<?php

class A {}
echo (new A) . ' ';
```
