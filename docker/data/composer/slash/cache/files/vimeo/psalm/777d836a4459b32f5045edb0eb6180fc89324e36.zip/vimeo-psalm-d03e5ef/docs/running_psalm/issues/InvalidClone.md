# InvalidClone

Emitted when trying to clone a value that's not cloneable

```php
<?php

$a = "hello";
$b = clone $a;
```
