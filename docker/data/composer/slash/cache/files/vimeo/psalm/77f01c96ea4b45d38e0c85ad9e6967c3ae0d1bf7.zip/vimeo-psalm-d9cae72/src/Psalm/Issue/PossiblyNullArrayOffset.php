<?php
namespace Psalm\Issue;

class PossiblyNullArrayOffset extends CodeIssue
{
}
