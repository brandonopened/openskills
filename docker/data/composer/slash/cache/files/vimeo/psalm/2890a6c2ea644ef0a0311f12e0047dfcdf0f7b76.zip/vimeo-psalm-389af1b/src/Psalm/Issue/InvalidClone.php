<?php
namespace Psalm\Issue;

class InvalidClone extends CodeIssue
{
}
