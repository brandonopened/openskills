<?php
namespace Psalm\Issue;

class TooFewArguments extends ArgumentIssue
{
}
