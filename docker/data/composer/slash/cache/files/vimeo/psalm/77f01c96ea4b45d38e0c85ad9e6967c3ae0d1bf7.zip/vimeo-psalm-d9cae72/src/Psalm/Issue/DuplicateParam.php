<?php
namespace Psalm\Issue;

class DuplicateParam extends CodeIssue
{
}
