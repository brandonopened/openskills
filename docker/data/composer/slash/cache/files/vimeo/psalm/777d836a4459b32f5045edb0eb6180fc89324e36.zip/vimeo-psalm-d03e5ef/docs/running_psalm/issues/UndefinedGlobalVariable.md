# UndefinedGlobalVariable

Emitted when referencing a variable that doesn't exist

```php
<?php

echo $a;
```
