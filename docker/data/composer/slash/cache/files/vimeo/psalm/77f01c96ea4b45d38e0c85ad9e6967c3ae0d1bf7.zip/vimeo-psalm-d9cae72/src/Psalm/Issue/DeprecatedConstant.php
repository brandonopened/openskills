<?php
namespace Psalm\Issue;

class DeprecatedConstant extends CodeIssue
{
}
