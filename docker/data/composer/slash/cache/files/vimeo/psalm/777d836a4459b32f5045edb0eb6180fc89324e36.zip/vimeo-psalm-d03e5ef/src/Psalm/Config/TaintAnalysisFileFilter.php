<?php
namespace Psalm\Config;

use SimpleXMLElement;
use function stripos;
use function strpos;

class TaintAnalysisFileFilter extends FileFilter
{
}
