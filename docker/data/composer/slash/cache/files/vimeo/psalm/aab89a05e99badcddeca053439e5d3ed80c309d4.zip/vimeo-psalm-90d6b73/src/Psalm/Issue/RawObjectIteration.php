<?php
namespace Psalm\Issue;

class RawObjectIteration extends CodeIssue
{
}
