# InvalidArrayAccess

Emitted when attempting to access an array offset on a value that does not permit it

```php
<?php

$arr = 5;
echo $arr[0];
```
