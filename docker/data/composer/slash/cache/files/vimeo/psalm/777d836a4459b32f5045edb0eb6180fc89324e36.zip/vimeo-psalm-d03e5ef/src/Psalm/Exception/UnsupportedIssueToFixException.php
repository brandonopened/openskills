<?php

namespace Psalm\Exception;

class UnsupportedIssueToFixException extends \Exception
{

}
