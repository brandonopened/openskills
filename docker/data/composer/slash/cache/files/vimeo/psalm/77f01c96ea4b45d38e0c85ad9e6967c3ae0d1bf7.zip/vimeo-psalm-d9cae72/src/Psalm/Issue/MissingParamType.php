<?php
namespace Psalm\Issue;

class MissingParamType extends CodeIssue
{
}
