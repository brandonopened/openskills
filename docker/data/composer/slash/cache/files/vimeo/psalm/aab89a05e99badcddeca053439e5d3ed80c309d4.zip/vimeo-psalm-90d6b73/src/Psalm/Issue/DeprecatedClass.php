<?php
namespace Psalm\Issue;

class DeprecatedClass extends ClassIssue
{
}
