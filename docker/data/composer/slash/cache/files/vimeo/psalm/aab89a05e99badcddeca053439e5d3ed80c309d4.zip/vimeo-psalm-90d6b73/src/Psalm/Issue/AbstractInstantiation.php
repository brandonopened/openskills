<?php
namespace Psalm\Issue;

class AbstractInstantiation extends CodeIssue
{
}
