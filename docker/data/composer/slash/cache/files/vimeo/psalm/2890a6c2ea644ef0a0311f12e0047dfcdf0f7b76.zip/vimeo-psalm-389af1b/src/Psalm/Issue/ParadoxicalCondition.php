<?php
namespace Psalm\Issue;

class ParadoxicalCondition extends CodeIssue
{
}
