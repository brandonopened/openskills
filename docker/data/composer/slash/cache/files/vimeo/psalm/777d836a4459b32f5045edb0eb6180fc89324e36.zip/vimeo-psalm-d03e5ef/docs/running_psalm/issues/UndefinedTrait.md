# UndefinedTrait

Emitted when referencing a trait that does not exist

```php
<?php

class A {
    use T;
}
```
