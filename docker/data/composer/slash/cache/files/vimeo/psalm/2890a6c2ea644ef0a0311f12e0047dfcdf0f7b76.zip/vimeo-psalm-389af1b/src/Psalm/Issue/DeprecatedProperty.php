<?php
namespace Psalm\Issue;

class DeprecatedProperty extends PropertyIssue
{
}
