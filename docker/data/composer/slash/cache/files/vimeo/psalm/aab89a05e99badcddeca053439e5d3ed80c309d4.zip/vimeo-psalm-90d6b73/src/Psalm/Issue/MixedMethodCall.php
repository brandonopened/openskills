<?php
namespace Psalm\Issue;

class MixedMethodCall extends CodeIssue
{
}
