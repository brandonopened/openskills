<?php
namespace Psalm\Issue;

class InvalidParamDefault extends CodeIssue
{
}
