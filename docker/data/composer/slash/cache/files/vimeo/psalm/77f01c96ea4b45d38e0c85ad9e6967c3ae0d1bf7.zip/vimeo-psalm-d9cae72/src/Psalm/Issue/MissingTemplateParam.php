<?php
namespace Psalm\Issue;

class MissingTemplateParam extends CodeIssue
{
}
