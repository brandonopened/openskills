<?php
namespace Psalm\Exception;

class ComplicatedExpressionException extends \Exception
{
}
