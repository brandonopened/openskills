<?php
namespace Psalm\Issue;

class PsalmInternalError extends CodeIssue
{
}
