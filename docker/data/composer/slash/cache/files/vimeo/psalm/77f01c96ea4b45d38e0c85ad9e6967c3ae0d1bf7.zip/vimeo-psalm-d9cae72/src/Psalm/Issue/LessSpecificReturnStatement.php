<?php
namespace Psalm\Issue;

class LessSpecificReturnStatement extends CodeIssue
{
}
