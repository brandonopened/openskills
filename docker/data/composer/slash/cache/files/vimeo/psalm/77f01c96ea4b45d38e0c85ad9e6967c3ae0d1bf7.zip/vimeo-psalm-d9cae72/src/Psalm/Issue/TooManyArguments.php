<?php
namespace Psalm\Issue;

class TooManyArguments extends ArgumentIssue
{
}
