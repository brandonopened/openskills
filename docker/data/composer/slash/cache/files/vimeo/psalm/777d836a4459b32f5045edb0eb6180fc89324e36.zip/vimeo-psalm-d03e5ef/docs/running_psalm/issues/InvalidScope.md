# InvalidScope

Emitted when referring to `$this` outside a class

```php
<?php

echo $this;
```
