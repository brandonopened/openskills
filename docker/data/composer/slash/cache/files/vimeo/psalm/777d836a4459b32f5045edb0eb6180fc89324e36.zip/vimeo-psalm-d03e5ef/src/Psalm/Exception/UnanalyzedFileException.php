<?php
namespace Psalm\Exception;

class UnanalyzedFileException extends \Exception
{
}
