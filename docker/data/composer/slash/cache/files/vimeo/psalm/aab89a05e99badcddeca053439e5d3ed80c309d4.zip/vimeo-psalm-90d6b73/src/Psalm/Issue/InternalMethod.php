<?php
namespace Psalm\Issue;

class InternalMethod extends MethodIssue
{
}
