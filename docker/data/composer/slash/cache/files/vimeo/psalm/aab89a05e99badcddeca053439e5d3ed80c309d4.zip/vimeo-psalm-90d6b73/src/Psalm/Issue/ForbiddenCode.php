<?php
namespace Psalm\Issue;

class ForbiddenCode extends CodeIssue
{
}
