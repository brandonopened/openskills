<?php
namespace Psalm\Internal\Type\ParseTree;

/**
 * @internal
 */
class CallableWithReturnTypeTree extends \Psalm\Internal\Type\ParseTree
{
}
