<?php
namespace Psalm\Issue;

class PossiblyInvalidPropertyFetch extends CodeIssue
{
}
