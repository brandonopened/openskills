<?php
namespace Psalm\Issue;

class NoInterfaceProperties extends ClassIssue
{
}
