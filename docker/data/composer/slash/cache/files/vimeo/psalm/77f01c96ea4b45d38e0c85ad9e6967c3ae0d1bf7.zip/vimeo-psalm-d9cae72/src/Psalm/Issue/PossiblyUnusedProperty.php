<?php
namespace Psalm\Issue;

class PossiblyUnusedProperty extends CodeIssue
{
}
