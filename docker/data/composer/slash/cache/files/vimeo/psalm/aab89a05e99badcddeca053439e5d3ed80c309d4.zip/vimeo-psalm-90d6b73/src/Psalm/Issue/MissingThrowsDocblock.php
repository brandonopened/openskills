<?php
namespace Psalm\Issue;

class MissingThrowsDocblock extends CodeIssue
{
}
