<?php
namespace Psalm\Issue;

class InvalidNullableReturnType extends CodeIssue
{
}
