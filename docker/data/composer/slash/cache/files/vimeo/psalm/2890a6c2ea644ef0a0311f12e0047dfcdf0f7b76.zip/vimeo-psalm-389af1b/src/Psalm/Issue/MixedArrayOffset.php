<?php
namespace Psalm\Issue;

class MixedArrayOffset extends CodeIssue
{
}
