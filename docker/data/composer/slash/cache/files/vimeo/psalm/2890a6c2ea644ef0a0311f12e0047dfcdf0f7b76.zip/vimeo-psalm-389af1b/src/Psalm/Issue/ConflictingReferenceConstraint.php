<?php
namespace Psalm\Issue;

class ConflictingReferenceConstraint extends CodeIssue
{
}
