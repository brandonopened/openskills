<?php
namespace Psalm\Issue;

class AssignmentToVoid extends CodeIssue
{
}
