<?php
namespace Psalm\Issue;

class InvalidFunctionCall extends CodeIssue
{
}
