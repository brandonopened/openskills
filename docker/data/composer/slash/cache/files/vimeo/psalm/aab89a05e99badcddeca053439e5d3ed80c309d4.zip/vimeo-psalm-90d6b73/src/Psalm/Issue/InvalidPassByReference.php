<?php
namespace Psalm\Issue;

class InvalidPassByReference extends CodeIssue
{
}
