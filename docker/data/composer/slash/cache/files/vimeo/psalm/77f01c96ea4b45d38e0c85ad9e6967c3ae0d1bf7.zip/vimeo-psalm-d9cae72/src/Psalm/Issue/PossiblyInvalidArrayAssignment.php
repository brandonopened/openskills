<?php
namespace Psalm\Issue;

class PossiblyInvalidArrayAssignment extends CodeIssue
{
}
