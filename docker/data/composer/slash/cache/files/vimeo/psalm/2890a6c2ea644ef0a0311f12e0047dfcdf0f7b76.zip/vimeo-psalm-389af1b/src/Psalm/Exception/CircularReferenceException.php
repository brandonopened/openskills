<?php
namespace Psalm\Exception;

class CircularReferenceException extends \Exception
{
}
