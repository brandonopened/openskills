<?php
namespace Psalm\Issue;

class MissingClosureReturnType extends CodeIssue
{
}
