<?php
namespace Psalm\Internal\Type\ParseTree;

/**
 * @internal
 */
class IntersectionTree extends \Psalm\Internal\Type\ParseTree
{
}
