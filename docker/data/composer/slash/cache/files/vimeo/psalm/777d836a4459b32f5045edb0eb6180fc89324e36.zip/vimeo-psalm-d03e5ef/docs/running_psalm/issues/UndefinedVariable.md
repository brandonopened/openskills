# UndefinedVariable

Emitted when referencing a variable that doesn't exist in a given function’s scope

```php
<?php

function foo() {
    echo $a;
}
```
