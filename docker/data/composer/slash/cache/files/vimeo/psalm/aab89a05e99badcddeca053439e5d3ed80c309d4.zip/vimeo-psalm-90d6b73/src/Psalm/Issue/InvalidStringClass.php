<?php
namespace Psalm\Issue;

class InvalidStringClass extends CodeIssue
{
}
