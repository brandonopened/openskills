<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

class UnresolvedAdditionOp extends UnresolvedBinaryOp
{
}
