<?php
namespace Psalm\Issue;

class InvalidFalsableReturnType extends CodeIssue
{
}
