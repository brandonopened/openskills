<?php
namespace Psalm\Issue;

class ReservedWord extends ClassIssue
{
}
