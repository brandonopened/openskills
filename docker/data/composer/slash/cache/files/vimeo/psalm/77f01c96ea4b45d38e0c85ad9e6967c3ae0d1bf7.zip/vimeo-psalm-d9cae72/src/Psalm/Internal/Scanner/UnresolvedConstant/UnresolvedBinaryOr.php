<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

class UnresolvedBinaryOr extends UnresolvedBinaryOp
{
}
