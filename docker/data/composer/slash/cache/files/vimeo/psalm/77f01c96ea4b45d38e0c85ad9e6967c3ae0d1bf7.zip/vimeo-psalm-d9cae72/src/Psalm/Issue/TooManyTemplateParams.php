<?php
namespace Psalm\Issue;

class TooManyTemplateParams extends CodeIssue
{
}
