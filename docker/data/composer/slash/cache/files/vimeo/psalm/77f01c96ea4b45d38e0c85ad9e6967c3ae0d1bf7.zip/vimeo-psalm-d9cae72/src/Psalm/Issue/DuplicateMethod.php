<?php
namespace Psalm\Issue;

class DuplicateMethod extends CodeIssue
{
}
