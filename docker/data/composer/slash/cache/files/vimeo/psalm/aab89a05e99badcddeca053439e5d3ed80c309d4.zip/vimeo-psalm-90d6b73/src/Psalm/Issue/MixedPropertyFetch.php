<?php
namespace Psalm\Issue;

class MixedPropertyFetch extends CodeIssue
{
}
