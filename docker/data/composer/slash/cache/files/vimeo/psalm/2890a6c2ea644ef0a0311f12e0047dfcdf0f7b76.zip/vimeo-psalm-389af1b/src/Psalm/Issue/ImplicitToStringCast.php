<?php
namespace Psalm\Issue;

class ImplicitToStringCast extends CodeIssue
{
}
