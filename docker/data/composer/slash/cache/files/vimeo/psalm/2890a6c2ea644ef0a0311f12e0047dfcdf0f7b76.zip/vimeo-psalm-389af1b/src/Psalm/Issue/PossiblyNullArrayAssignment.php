<?php
namespace Psalm\Issue;

class PossiblyNullArrayAssignment extends CodeIssue
{
}
