<?php
namespace Psalm\Issue;

class PropertyNotSetInConstructor extends PropertyIssue
{
}
