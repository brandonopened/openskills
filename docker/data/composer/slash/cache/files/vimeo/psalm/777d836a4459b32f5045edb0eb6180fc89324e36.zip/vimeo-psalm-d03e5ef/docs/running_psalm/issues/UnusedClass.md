# UnusedClass

Emitted when `--find-dead-code` is turned on and Psalm cannot find any uses of a given class

```php
<?php

class A {}
class B {}
$a = new A();
```
