<?php
namespace Psalm\Issue;

class PossiblyUnusedParam extends CodeIssue
{
}
