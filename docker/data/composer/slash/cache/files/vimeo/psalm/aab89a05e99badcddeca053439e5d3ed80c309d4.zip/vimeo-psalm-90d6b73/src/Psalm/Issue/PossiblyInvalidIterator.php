<?php
namespace Psalm\Issue;

class PossiblyInvalidIterator extends CodeIssue
{
}
