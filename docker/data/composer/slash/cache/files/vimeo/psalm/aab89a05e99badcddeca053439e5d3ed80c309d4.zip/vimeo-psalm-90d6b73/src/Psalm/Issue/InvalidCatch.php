<?php
namespace Psalm\Issue;

class InvalidCatch extends ClassIssue
{
}
