<?php
namespace Psalm\Issue;

class PossiblyUndefinedVariable extends CodeIssue
{
}
