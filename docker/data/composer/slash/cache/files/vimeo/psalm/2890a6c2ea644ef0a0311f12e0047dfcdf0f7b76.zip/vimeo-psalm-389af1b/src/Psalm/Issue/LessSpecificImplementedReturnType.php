<?php
namespace Psalm\Issue;

class LessSpecificImplementedReturnType extends CodeIssue
{
}
