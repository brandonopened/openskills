<?php
namespace Psalm\Internal\Fork;

interface ForkMessage
{
}
