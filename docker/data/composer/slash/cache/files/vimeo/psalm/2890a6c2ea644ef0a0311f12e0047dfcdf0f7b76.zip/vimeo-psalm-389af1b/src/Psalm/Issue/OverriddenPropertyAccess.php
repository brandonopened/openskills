<?php
namespace Psalm\Issue;

class OverriddenPropertyAccess extends CodeIssue
{
}
