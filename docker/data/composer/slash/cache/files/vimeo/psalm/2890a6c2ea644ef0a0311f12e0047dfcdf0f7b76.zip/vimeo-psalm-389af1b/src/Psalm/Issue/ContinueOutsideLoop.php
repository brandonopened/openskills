<?php
namespace Psalm\Issue;

class ContinueOutsideLoop extends CodeIssue
{
}
