<?php

namespace Psalm\Internal\Scanner;

abstract class UnresolvedConstantComponent
{
}
