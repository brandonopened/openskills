<?php
namespace Psalm\Issue;

class InvalidParent extends CodeIssue
{

}
