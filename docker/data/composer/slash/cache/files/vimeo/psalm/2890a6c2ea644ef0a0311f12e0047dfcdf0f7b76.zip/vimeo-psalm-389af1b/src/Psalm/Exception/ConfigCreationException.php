<?php
namespace Psalm\Exception;

class ConfigCreationException extends \Exception
{
}
