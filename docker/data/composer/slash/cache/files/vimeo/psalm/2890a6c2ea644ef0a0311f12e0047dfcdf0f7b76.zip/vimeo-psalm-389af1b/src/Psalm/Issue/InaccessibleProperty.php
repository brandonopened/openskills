<?php
namespace Psalm\Issue;

class InaccessibleProperty extends CodeIssue
{
}
