<?php
namespace Psalm\Issue;

class PossiblyUndefinedArrayOffset extends CodeIssue
{
}
