<?php
namespace Psalm\Exception;

class ConfigException extends \Exception
{
}
