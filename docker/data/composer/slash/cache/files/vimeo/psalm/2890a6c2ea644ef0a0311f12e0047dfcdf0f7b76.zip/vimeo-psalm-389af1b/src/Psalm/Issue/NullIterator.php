<?php
namespace Psalm\Issue;

class NullIterator extends CodeIssue
{
}
