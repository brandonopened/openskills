<?php
namespace Psalm\Issue;

class PossiblyInvalidMethodCall extends CodeIssue
{
}
