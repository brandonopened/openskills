<?php
namespace Psalm\Issue;

class PossiblyInvalidPropertyAssignment extends CodeIssue
{
}
