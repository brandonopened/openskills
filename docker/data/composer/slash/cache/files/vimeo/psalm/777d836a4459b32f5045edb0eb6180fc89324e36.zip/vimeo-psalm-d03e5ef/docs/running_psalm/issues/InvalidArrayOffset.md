# InvalidArrayOffset

Emitted when attempting to access an array using a value that's not a valid offset for that array

```php
<?php

$a = [5, 20, 18];
echo $a["hello"];
```
