<?php
namespace Psalm\Issue;

class PossiblyFalseReference extends CodeIssue
{
}
