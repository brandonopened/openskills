<?php
namespace Psalm\Issue;

class NullArgument extends ArgumentIssue
{
}
