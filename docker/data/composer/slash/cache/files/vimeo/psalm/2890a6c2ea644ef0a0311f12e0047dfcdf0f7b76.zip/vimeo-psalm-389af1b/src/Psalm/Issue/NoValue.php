<?php
namespace Psalm\Issue;

class NoValue extends CodeIssue
{
}
