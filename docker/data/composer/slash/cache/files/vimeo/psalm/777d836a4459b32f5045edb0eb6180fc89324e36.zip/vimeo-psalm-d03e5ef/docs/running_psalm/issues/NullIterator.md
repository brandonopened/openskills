# NullIterator

Emitted when iterating over `null`

```php
<?php

foreach (null as $a) {}
```
