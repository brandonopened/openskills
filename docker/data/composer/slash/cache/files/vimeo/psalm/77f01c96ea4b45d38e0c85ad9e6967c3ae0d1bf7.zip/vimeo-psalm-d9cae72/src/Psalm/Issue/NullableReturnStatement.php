<?php
namespace Psalm\Issue;

class NullableReturnStatement extends CodeIssue
{
}
