<?php
namespace Psalm\Issue;

class InvalidStaticInvocation extends CodeIssue
{
}
