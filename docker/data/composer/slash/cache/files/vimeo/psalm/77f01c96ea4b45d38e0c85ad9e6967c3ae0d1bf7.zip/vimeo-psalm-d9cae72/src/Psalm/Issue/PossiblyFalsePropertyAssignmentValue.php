<?php
namespace Psalm\Issue;

class PossiblyFalsePropertyAssignmentValue extends PropertyIssue
{
}
