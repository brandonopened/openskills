<?php
namespace Psalm\Issue;

class MixedOperand extends CodeIssue
{
}
