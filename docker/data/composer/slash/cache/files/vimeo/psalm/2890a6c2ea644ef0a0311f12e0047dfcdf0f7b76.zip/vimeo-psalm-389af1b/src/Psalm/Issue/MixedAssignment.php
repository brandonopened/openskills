<?php
namespace Psalm\Issue;

class MixedAssignment extends CodeIssue
{
}
