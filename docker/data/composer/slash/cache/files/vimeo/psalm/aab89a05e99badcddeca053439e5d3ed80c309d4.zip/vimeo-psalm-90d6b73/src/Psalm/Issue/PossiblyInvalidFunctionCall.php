<?php
namespace Psalm\Issue;

class PossiblyInvalidFunctionCall extends CodeIssue
{
}
