<?php
namespace Psalm\Issue;

class LessSpecificReturnType extends CodeIssue
{
}
