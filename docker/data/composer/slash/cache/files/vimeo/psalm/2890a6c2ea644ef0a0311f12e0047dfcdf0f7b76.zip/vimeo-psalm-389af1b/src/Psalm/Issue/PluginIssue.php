<?php
namespace Psalm\Issue;

abstract class PluginIssue extends CodeIssue
{
}
