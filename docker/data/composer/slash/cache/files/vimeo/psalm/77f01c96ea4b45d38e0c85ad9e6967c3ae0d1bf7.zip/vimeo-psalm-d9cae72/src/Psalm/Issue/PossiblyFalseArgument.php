<?php
namespace Psalm\Issue;

class PossiblyFalseArgument extends ArgumentIssue
{
}
