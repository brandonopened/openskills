<?php
namespace Psalm\Issue;

class MixedArgument extends ArgumentIssue
{
}
