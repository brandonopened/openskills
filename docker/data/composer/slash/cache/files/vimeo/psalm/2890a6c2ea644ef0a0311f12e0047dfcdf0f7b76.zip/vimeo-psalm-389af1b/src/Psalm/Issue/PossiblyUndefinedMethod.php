<?php
namespace Psalm\Issue;

class PossiblyUndefinedMethod extends MethodIssue
{
}
