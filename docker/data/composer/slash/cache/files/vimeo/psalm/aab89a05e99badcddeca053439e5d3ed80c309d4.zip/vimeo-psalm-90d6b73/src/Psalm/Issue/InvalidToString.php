<?php
namespace Psalm\Issue;

class InvalidToString extends CodeIssue
{
}
