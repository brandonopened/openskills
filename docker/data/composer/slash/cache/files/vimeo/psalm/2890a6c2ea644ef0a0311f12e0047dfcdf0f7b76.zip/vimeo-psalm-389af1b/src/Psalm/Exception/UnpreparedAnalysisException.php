<?php
namespace Psalm\Exception;

class UnpreparedAnalysisException extends \Exception
{
}
