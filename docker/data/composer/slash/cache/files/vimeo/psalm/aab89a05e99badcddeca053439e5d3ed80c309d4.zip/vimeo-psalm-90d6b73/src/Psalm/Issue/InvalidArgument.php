<?php
namespace Psalm\Issue;

class InvalidArgument extends ArgumentIssue
{
}
