<?php
namespace Psalm\Issue;

class DeprecatedFunction extends FunctionIssue
{
}
