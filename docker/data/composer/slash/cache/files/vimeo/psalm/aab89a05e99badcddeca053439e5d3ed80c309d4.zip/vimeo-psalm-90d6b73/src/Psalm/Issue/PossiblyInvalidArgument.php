<?php
namespace Psalm\Issue;

class PossiblyInvalidArgument extends ArgumentIssue
{
}
