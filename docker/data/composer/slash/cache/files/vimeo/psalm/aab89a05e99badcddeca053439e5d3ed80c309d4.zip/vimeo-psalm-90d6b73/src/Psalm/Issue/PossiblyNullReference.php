<?php
namespace Psalm\Issue;

class PossiblyNullReference extends CodeIssue
{
}
