<?php
namespace Psalm\Issue;

class InvalidIterator extends CodeIssue
{
}
