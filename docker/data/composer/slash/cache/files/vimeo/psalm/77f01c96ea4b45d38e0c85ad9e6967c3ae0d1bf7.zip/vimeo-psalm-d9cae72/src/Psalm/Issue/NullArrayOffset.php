<?php
namespace Psalm\Issue;

class NullArrayOffset extends CodeIssue
{
}
