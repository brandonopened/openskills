<?php
namespace Psalm\Issue;

class PossiblyInvalidArrayOffset extends CodeIssue
{
}
