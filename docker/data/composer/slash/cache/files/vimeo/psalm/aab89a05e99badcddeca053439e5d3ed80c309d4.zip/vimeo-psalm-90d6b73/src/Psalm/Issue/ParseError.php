<?php
namespace Psalm\Issue;

class ParseError extends CodeIssue
{
}
