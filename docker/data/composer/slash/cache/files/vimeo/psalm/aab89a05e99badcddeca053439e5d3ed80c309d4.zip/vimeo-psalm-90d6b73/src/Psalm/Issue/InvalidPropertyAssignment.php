<?php
namespace Psalm\Issue;

class InvalidPropertyAssignment extends CodeIssue
{
}
