<?php

namespace Psalm\Exception;

class InvalidMethodOverrideException extends \Exception
{
}
