<?php
namespace Psalm\Issue;

class DocblockTypeContradiction extends CodeIssue
{
}
