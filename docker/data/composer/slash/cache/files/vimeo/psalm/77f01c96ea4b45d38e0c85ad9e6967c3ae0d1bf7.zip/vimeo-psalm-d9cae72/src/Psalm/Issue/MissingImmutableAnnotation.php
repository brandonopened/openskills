<?php
namespace Psalm\Issue;

class MissingImmutableAnnotation extends CodeIssue
{
}
