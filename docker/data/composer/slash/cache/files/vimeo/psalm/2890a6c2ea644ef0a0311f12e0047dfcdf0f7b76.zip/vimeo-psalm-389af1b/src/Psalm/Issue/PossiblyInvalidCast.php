<?php
namespace Psalm\Issue;

class PossiblyInvalidCast extends CodeIssue
{
}
