<?php
namespace Psalm\Issue;

class ReferenceConstraintViolation extends CodeIssue
{
}
