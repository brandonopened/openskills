<?php
namespace Psalm\Issue;

class MismatchingDocblockParamType extends CodeIssue
{
}
