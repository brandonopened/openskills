<?php
namespace Psalm\Issue;

class DeprecatedTrait extends CodeIssue
{
}
