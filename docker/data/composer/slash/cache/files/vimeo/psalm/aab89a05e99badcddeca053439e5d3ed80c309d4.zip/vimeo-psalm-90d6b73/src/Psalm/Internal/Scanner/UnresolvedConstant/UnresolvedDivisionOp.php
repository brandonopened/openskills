<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

class UnresolvedDivisionOp extends UnresolvedBinaryOp
{
}
