<?php
namespace Psalm\Internal\Type\ParseTree;

/**
 * @internal
 */
class EncapsulationTree extends \Psalm\Internal\Type\ParseTree
{
}
