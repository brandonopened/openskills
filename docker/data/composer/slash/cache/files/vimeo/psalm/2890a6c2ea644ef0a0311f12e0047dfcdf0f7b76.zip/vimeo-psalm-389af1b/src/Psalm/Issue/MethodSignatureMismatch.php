<?php
namespace Psalm\Issue;

class MethodSignatureMismatch extends CodeIssue
{
}
