<?php
namespace Psalm\Issue;

class PropertyTypeCoercion extends PropertyIssue
{
}
