<?php
namespace Psalm\Issue;

class PossiblyNullFunctionCall extends CodeIssue
{
}
