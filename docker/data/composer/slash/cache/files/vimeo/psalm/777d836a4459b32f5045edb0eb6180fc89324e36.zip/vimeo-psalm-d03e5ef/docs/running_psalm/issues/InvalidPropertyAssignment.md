# InvalidPropertyAssignment

Emitted when attempting to assign a property to a non-object

```php
<?php

$a = "foo";
$a->bar = "bar";
```
