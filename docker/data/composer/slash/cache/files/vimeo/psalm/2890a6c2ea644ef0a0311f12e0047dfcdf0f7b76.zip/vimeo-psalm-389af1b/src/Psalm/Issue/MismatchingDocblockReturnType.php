<?php
namespace Psalm\Issue;

class MismatchingDocblockReturnType extends CodeIssue
{
}
