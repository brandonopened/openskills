<?php
namespace Psalm\Issue;

class InvalidPropertyAssignmentValue extends PropertyIssue
{
}
