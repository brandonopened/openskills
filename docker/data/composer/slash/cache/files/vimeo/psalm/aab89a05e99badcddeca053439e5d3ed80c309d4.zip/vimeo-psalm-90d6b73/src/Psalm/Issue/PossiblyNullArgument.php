<?php
namespace Psalm\Issue;

class PossiblyNullArgument extends ArgumentIssue
{
}
