<?php
namespace Psalm\Issue;

class PossiblyFalseOperand extends CodeIssue
{
}
