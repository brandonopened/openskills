<?php
namespace Psalm\Issue;

class NullFunctionCall extends CodeIssue
{
}
