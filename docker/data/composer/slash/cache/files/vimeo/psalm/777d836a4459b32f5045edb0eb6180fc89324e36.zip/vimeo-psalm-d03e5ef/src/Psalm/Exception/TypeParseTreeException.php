<?php
namespace Psalm\Exception;

class TypeParseTreeException extends \Exception
{
}
