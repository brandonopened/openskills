# InterfaceInstantiation

Emitted when an attempt is made to instantiate an interface:

```php
<?php

interface I {}
new I();
```
