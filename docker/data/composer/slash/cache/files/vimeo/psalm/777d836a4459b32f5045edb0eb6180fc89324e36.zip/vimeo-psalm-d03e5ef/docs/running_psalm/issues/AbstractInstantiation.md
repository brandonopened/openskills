# AbstractInstantiation

Emitted when an attempt is made to instantiate an abstract class:

```php
<?php

abstract class A {}
new A();
```
