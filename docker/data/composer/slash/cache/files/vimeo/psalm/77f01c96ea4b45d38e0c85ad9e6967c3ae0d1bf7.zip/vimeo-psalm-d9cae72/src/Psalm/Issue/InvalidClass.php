<?php
namespace Psalm\Issue;

class InvalidClass extends ClassIssue
{
}
