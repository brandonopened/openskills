<?php
namespace Psalm\Issue;

class MixedInferredReturnType extends CodeIssue
{
}
