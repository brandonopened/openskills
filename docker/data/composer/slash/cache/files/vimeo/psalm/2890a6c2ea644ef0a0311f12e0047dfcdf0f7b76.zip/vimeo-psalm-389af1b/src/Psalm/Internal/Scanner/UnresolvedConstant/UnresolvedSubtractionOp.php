<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

class UnresolvedSubtractionOp extends UnresolvedBinaryOp
{
}
