<?php
namespace Psalm\Issue;

class InvalidArrayOffset extends CodeIssue
{
}
