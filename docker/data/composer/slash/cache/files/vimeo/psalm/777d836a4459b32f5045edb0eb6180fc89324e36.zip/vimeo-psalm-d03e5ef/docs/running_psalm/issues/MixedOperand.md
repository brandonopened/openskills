# MixedOperand

Emitted when Psalm cannot infer a type for an operand in any calculated expression

```php
<?php

echo $_GET['foo'] + "hello";
```
