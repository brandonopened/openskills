<?php
namespace Psalm\Issue;

class MissingReturnType extends CodeIssue
{
}
