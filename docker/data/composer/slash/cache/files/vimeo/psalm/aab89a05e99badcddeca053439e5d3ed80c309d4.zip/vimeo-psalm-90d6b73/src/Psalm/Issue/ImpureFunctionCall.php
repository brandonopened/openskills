<?php
namespace Psalm\Issue;

class ImpureFunctionCall extends CodeIssue
{
}
