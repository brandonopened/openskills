#!/usr/bin/env bash

set -ex

vendor/bin/phpcs

