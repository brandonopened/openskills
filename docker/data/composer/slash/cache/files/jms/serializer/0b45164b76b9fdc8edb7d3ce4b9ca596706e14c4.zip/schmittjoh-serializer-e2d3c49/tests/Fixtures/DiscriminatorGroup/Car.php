<?php

declare(strict_types=1);

namespace JMS\Serializer\Tests\Fixtures\DiscriminatorGroup;

class Car extends Vehicle
{
}
