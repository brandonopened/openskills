<?php

declare(strict_types=1);

namespace JMS\Serializer\Tests\Fixtures\Discriminator;

class ObjectWithXmlNamespaceAttributeDiscriminatorChild extends ObjectWithXmlNamespaceAttributeDiscriminatorParent
{
}
