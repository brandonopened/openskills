#!/usr/bin/env bash

set -ex

pip install -r doc/requirements.txt --user
