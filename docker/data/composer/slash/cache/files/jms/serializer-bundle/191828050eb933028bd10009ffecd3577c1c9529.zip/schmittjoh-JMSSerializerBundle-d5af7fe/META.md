# Generating changelog

Use: https://github.com/skywinder/Github-Changelog-Generator

```bash
github_changelog_generator --user=schmittjoh --project=JMSSerializerBundle --pull-requests --no-compare-link --future-release=RELEASE_NR -t GITHUB-TOKEN
```
