JMSSerializerBundle
===================


[![Build Status](https://api.travis-ci.org/schmittjoh/JMSSerializerBundle.svg)](https://travis-ci.org/schmittjoh/JMSSerializerBundle)
[![Scrutinizer Quality Score](https://scrutinizer-ci.com/g/schmittjoh/JMSSerializerBundle/badges/quality-score.png)](https://scrutinizer-ci.com/g/schmittjoh/JMSSerializerBundle/)
[![Code Coverage](https://scrutinizer-ci.com/g/schmittjoh/JMSSerializerBundle/badges/coverage.png)](https://scrutinizer-ci.com/g/schmittjoh/JMSSerializerBundle/)
[![Packagist](https://img.shields.io/packagist/v/jms/serializer-bundle.svg)](https://packagist.org/packages/jms/serializer-bundle)

This bundle integrates the [serializer library](https://github.com/schmittjoh/serializer) into Symfony.

Please open new issues or feature request which are related to the library on the new repository.

## Documentation

You can learn more about the bundle in its [documentation](http://jmsyst.com/bundles/JMSSerializerBundle).

## Professional Support

For eventual paid support please write an email to [goetas@gmail.com](mailto:goetas@gmail.com).
