<?php

namespace kamermans\OAuth2\Exception;

class OAuth2Exception extends \RuntimeException
{
}
