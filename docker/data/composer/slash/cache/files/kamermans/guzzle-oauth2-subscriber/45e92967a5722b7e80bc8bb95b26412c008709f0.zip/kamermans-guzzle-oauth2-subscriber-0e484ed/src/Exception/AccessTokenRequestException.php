<?php

namespace kamermans\OAuth2\Exception;

class AccessTokenRequestException extends ReauthorizationRequestException
{
}
