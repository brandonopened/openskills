<?php

namespace kamermans\OAuth2\Signer\AccessToken;

// This class exists for backwards compatibility
class BasicAuth extends BearerAuth
{
}
