<?php

namespace kamermans\OAuth2\Exception;

class ReauthorizationException extends OAuth2Exception
{
}
