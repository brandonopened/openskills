<?php

$container->loadFromExtension('swiftmailer', [
    'antiflood' => true,
]);
