<?php
namespace Codeception\Exception;

class ConfigurationException extends \Exception
{
}
