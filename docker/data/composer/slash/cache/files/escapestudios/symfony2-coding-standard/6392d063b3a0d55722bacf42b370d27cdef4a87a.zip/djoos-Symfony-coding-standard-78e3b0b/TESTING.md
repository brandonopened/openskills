# Testing

Contributions to this repository will only be accepted if all tests pass successfully.

## Setting up the test environment

* install PHP
* install [Java](https://java.com)/[Apache ant](https://ant.apache.org)

...not a fan of Java/ant?
Run the individual commands listed in build.xml manually!

## Running tests
`ant test`
