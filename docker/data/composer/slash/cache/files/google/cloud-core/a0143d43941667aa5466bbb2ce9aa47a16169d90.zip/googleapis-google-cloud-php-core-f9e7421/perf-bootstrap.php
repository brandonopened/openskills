<?php

use Google\Cloud\Core\Testing\TestHelpers;

TestHelpers::perfBootstrap();
