<?php

namespace Swaggest\JsonSchema\Exception;


use Swaggest\JsonSchema\InvalidValue;

class TypeException extends InvalidValue
{

}