<?php

namespace Swaggest\JsonSchema\Exception;


use Swaggest\JsonSchema\InvalidValue;

class ContentException extends InvalidValue
{

}