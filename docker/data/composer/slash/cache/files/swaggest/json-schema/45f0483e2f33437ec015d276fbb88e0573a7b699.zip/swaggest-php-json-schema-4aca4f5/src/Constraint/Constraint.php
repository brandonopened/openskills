<?php

namespace Swaggest\JsonSchema\Constraint;

interface Constraint
{
}