<?php

namespace Swaggest\JsonSchema\Exception;

use Swaggest\JsonSchema\InvalidValue;

class ConstException extends InvalidValue
{

}