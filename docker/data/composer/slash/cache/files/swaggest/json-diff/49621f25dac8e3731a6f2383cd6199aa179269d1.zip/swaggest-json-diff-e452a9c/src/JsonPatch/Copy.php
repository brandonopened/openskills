<?php

namespace Swaggest\JsonDiff\JsonPatch;

class Copy extends OpPathFrom
{
    const OP = 'copy';
}