<?php

namespace Swaggest\JsonDiff;


class Exception extends \Exception
{
    const EMPTY_PROPERTY_NAME_UNSUPPORTED = 1;
}