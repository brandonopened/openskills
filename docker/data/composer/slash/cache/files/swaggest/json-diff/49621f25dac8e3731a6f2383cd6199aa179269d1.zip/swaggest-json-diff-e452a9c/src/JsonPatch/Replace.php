<?php

namespace Swaggest\JsonDiff\JsonPatch;

class Replace extends OpPathValue
{
    const OP = 'replace';
}