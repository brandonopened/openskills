<?php

namespace Swaggest\JsonDiff\JsonPatch;

class Add extends OpPathValue
{
    const OP = 'add';
}