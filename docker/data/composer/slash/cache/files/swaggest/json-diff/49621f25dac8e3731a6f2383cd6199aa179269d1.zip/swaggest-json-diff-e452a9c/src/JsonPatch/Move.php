<?php

namespace Swaggest\JsonDiff\JsonPatch;

class Move extends OpPathFrom
{
    const OP = 'move';
}