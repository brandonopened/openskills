<?php

namespace Swaggest\JsonDiff\JsonPatch;

class Remove extends OpPath
{
    const OP = 'remove';
}