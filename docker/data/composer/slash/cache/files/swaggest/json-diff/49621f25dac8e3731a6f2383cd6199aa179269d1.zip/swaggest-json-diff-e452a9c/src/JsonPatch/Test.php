<?php

namespace Swaggest\JsonDiff\JsonPatch;

class Test extends OpPathValue
{
    const OP = 'test';
}