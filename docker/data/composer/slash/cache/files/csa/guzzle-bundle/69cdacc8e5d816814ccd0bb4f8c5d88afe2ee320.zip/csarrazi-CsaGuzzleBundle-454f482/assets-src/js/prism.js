import Prism from 'prismjs/components/prism-core'
import 'prismjs/components/prism-json'
import 'prismjs/components/prism-markup'
import 'prismjs/plugins/line-numbers/prism-line-numbers'

Prism.languages.xml = Prism.languages.extend('markup');