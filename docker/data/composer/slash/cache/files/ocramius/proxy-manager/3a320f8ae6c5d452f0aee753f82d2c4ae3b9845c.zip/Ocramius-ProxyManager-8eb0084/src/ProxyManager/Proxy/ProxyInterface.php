<?php

declare(strict_types=1);

namespace ProxyManager\Proxy;

/**
 * Base proxy marker
 *
 * @psalm-template DecoratedClassName of object
 */
interface ProxyInterface
{
}
