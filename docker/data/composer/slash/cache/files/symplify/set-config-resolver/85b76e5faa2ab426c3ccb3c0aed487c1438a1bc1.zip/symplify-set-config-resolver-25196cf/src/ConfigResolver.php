<?php

declare(strict_types=1);

namespace Symplify\SetConfigResolver;

/**
 * @see \Symplify\SetConfigResolver\Tests\ConfigResolver\ConfigResolverTest
 */
final class ConfigResolver extends AbstractConfigResolver
{
}
