<?php

declare(strict_types=1);

namespace Symplify\CodingStandard\TokenRunner\Exception;

use Exception;

final class MissingImplementationException extends Exception
{
}
