<?php

declare(strict_types=1);

namespace Symplify\CodingStandard\ObjectCalisthenics\Tests\Rules\TooManyPropertiesRule\Fixture;

final class TooManyProperties
{
    private $firstPropeprty;

    private $secondPropeprty;

    private $thirdPropeprty;

    private $fourthPropeprty;
}
