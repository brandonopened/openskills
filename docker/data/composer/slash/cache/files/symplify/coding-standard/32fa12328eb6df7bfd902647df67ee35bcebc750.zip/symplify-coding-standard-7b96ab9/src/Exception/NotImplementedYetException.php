<?php

declare(strict_types=1);

namespace Symplify\CodingStandard\Exception;

use Exception;

final class NotImplementedYetException extends Exception
{
}
