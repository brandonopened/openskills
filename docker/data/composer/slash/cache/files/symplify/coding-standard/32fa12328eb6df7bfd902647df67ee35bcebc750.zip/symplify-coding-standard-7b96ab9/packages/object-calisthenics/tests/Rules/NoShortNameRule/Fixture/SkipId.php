<?php

declare(strict_types=1);

namespace Symplify\CodingStandard\ObjectCalisthenics\Tests\Rules\NoShortNameRule\Fixture;

final class ShortNamingClass
{
    private $id;
}
