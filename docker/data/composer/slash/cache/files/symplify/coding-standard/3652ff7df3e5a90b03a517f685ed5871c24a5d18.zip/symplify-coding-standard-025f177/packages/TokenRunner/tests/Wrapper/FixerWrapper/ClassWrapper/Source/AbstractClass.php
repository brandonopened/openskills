<?php

declare(strict_types=1);

namespace Symplify\CodingStandard\TokenRunner\Tests\Wrapper\FixerWrapper\ClassWrapper\Source;

abstract class AbstractClass implements SomeInterface
{
}
