<?php

declare(strict_types=1);

namespace Symplify\SmartFileSystem\Tests\Finder\FinderSanitizer\Source\NestedDirectory;

final class FileWithClass
{
}
