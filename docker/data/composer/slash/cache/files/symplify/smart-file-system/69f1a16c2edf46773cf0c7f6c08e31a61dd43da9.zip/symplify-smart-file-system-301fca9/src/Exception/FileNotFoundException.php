<?php

declare(strict_types=1);

namespace Symplify\SmartFileSystem\Exception;

use Exception;

final class FileNotFoundException extends Exception
{
}
