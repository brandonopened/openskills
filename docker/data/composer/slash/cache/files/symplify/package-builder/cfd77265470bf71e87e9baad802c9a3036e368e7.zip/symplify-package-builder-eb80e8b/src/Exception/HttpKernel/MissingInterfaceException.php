<?php

declare(strict_types=1);

namespace Symplify\PackageBuilder\Exception\HttpKernel;

use Exception;

final class MissingInterfaceException extends Exception
{
}
