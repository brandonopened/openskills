<?php

declare(strict_types=1);

namespace Symplify\PackageBuilder\Exception\Configuration;

use Exception;

final class LevelNotFoundException extends Exception
{
}
