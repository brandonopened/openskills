<?php

declare(strict_types=1);

namespace Symplify\PackageBuilder\Exception;

use Exception;

final class FilePathNotAbsoluteException extends Exception
{
}
