<?php

declare(strict_types=1);

namespace Symplify\PackageBuilder\Exception\Parameter;

use Exception;

final class ParameterTypoException extends Exception
{
}
