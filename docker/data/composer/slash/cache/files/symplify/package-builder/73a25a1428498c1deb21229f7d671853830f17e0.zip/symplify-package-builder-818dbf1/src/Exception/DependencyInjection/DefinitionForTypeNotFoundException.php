<?php

declare(strict_types=1);

namespace Symplify\PackageBuilder\Exception\DependencyInjection;

use Exception;

final class DefinitionForTypeNotFoundException extends Exception
{
}
