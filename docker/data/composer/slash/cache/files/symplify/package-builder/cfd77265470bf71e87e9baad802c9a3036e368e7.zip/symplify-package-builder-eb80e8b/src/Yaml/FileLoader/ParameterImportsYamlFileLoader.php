<?php

declare(strict_types=1);

namespace Symplify\PackageBuilder\Yaml\FileLoader;

final class ParameterImportsYamlFileLoader extends AbstractParameterImportsYamlFileLoader
{
}
