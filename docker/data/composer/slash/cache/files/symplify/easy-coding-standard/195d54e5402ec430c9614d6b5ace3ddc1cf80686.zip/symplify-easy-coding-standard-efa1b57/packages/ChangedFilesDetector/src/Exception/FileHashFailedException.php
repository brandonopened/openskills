<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\ChangedFilesDetector\Exception;

use Exception;

final class FileHashFailedException extends Exception
{
}
