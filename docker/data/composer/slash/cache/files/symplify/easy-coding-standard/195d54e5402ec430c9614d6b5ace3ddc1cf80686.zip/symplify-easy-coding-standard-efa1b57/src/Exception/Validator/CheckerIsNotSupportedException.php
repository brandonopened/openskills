<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\Exception\Validator;

use Exception;

final class CheckerIsNotSupportedException extends Exception
{
}
