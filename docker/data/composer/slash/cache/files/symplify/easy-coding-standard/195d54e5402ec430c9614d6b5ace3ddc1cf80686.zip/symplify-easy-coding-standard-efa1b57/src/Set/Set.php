<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\Set;

final class Set
{
    /**
     * @var string
     */
    public const SET_DIRECTORY = __DIR__ . '/../../config/set';
}
