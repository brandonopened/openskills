<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\SniffRunner\Exception\File;

use Exception;

final class NotImplementedException extends Exception
{
}
