<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\FixerRunner\Exception\Application;

use Exception;

final class FixerFailedException extends Exception
{
}
