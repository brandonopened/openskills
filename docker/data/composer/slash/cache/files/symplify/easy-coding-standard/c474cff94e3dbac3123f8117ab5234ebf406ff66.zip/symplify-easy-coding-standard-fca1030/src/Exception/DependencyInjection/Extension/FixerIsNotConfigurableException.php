<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\Exception\DependencyInjection\Extension;

use Exception;

final class FixerIsNotConfigurableException extends Exception
{
}
