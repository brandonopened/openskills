<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\Exception\Finder;

use Exception;

final class InvalidSourceTypeException extends Exception
{
}
