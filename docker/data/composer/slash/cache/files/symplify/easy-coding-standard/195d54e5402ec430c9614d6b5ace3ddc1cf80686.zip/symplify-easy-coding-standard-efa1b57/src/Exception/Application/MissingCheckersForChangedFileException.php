<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\Exception\Application;

use Exception;

final class MissingCheckersForChangedFileException extends Exception
{
}
