<?php

declare(strict_types=1);

namespace Symplify\EasyCodingStandard\Contract\Application;

interface DualRunInterface
{
    public function increaseRun(): void;
}
