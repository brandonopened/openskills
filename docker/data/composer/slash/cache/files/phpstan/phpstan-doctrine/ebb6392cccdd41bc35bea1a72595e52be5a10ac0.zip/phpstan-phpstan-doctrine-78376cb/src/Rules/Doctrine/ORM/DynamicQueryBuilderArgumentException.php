<?php declare(strict_types = 1);

namespace PHPStan\Rules\Doctrine\ORM;

use Exception;

class DynamicQueryBuilderArgumentException extends Exception
{

}
