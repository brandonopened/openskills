<?php declare(strict_types = 1);

namespace PHPStan\Type\Accessory;

use PHPStan\Type\Type;

interface AccessoryType extends Type
{

}
