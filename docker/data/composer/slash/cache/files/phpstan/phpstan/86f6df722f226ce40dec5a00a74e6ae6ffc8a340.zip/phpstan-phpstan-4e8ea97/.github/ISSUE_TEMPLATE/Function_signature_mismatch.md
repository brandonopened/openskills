---
name: Function signature mismatch 🤖
about: Some built-in PHP function expects or returns a different type than is reported?
---

<!-- Please send a pull request that updates file src/Reflection/SignatureMap/functionMap.php instead. Thank you. -->
