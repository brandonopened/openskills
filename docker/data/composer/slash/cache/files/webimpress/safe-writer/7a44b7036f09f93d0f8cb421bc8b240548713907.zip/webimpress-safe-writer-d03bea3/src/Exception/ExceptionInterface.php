<?php

declare(strict_types=1);

namespace Webimpress\SafeWriter\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
